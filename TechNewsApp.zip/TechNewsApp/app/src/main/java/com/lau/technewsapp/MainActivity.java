package com.lau.technewsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity {
    //String  articleID=" ";
    String id="";
    String title="";
    String url="";


//    String webContent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        String apiURL = "https://hacker-news.firebaseio.com/v0/topstories.json";


        String article = "https://hacker-news.firebaseio.com/v0/item/29259497.json?print=pretty";


        DownloadTask task = new DownloadTask();



        task.execute(apiURL);
       // task.execute(article);

        try {

            SQLiteDatabase db = this.openOrCreateDatabase("assignmentdb", MODE_PRIVATE, null);


            db.execSQL("CREATE TABLE IF NOT EXISTS finds (article_nbr VARCHAR,article_name VARCHAR,url VARCHAR)");

            db.execSQL("INSERT INTO finds(article_nbr,article_name,url) VALUES(\"" + id + "\" ,\"" + title + "\" ,\"" + url + "\" )");


            Cursor d= db.rawQuery("Select * from finds", null);
            int idIndex = d.getColumnIndex("article_nbr");
            int nameIndex = d.getColumnIndex("article_name");
            int htmlIndex = d.getColumnIndex("url");
            d.moveToFirst();

            while (d != null) {
                Log.i("qq", d.getString(idIndex));
                Log.i("qq", d.getString(nameIndex));
                Log.i("qq", d.getString(htmlIndex));
                d.moveToNext();
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }



    public class DownloadTask extends AsyncTask<String, Void, String> {

        protected String doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection;
            try {

                    url = new URL(urls[0]);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    InputStream in = urlConnection.getInputStream();
                    InputStreamReader reader = new InputStreamReader(in);
                    int data = reader.read();

                    while (data != -1) {
                        char current = (char) data;
                        result += current;
                        data = reader.read();
                    }


                    return result;
                } catch(Exception e){
                    e.printStackTrace();
                    return null;
                }


            }


        protected void onPostExecute(String s) {
            super.onPostExecute(s);



            try {

                //Part 1 to fetch the ids from original API and store them into Array

                String ID = json.getString(s);
                  JSONArray arr = new JSONArray(s);

              //   //Part 2 to fetch the Details from an API

//                JSONObject json = new JSONObject(s);
//
//                id = json.getString("id");
//                title = json.getString("title");
//                url = json.getString("url");
//
//
//                Log.i("test1",id);
//                Log.i("test1",title);
//                Log.i("test1",url);





            } catch (Exception e) {
                e.printStackTrace();
            }

        }


    }

}

